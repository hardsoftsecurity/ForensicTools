# Changelog

## 3.6.5-19 (2022/06/05)

* Wireshark 3.6.5
* Portapps 3.5.0

## 3.6.2-18 (2022/03/06)

* Wireshark 3.6.2
* Portapps 3.4.0

## 3.4.6-17 (2021/06/18)

* Wireshark 3.4.6

## 3.4.4-16 (2021/04/03)

* Wireshark 3.4.4
* Portapps 3.3.0
* No more win32 release

## 3.4.2-15 (2020/12/19)

* Wireshark 3.4.2
* Portapps 3.1.0

## 3.2.7-14 (2020/10/05)

* Wireshark 3.2.7

## 3.2.6-13 (2020/08/18)

* Wireshark 3.2.6
* Portapps 2.6.0

## 3.2.5-12 (2020/07/15)

* Wireshark 3.2.5

## 3.2.4-11 (2020/06/02)

* Wireshark 3.2.4
* Portapps 2.4.4

## 3.2.3-10 (2020/04/14)

* Wireshark 3.2.3
* Portapps 2.1.2

## 3.2.2-9 (2020/03/04)

* Wireshark 3.2.2

## 3.2.1-8 (2020/01/23)

* Wireshark 3.2.1

## 3.2.0-7 (2019/12/19)

* Wireshark 3.2.0
* Portapps 1.31.0

## 3.0.7-6 (2019/12/06)

* Wireshark 3.0.7
* Portapps 1.30.1

## 3.0.6-5 (2019/10/24)

* Wireshark 3.0.6
* Portapps 1.28.0

## 3.0.5-4 (2019/10/04)

* Wireshark 3.0.5
* Portapps 1.27.0

## 3.0.4-3 (2019/09/13)

* Wireshark 3.0.4
* Disable auto update check (Issue #1)
* Portapps 1.26.1

## 3.0.3-2 (2019/07/19)

* Wireshark 3.0.3

## 3.0.2-1 (2019/05/27)

* Initial version based on Wireshark 3.0.2
